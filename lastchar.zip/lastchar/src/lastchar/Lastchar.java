/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lastchar;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Lastchar {

    /**
     * @param args the command line arguments
     */
    
           
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner sin=new Scanner(System.in);

        String s1;
int lastchar;

       System.out.println("enter the string");
        s1=sin.next();
        char[] c=new char[25];
        c=s1.toCharArray();
       lastchar=c.length-1;
               
        System.out.println(c[lastchar]);
    }
   
}
