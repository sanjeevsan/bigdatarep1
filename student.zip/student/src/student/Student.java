/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.util.Scanner;

/**
 *
 * @author San
 */
public class Student {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
Scanner sin=new Scanner(System.in);
String id,name,city,country;
int age;
System.out.println("enter the id");
id=sin.next();
char[] s1=id.toCharArray();
if(s1[0]!='S'||s1[0]!='s')
    
{
    if(s1.length>5)
    {
    System.out.println("invalid");
}
}

System.out.println("enter the name");

name=sin.next();
System.out.println("enter the city");
city=sin.next();
System.out.println("enter the country");
country=sin.next();
if(country!="india")
{
    System.out.println("invalid");
}
System.out.println("enter the age ");
age=sin.nextInt();
if(age>100)
{
    System.out.println("age must not be greater than 100");

}

    }
    
}
