/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayl;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author San
 */
public class Arrayl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       A obj=new A();
       obj.show();
        
    }
    
}
class A
{
    public void show()
    {
        ArrayList details=new ArrayList();
        details.add("kumar");
        details.add(21);
        details.add("chenai");
        details.add("tamil nadu");
        
         details.add("xxx");
        details.add(22);
        details.add("chennai");
        details.add("tamil ");
        
         details.add("yyy");
        details.add(24);
        details.add("ch");
        details.add(" nadu");
        
         details.add("zzz");
        details.add(22);
        details.add("chennnnnai");
        details.add("tamilbkjbkjb nadu");
        
        System.out.println(details);
        Iterator iterato=details.iterator();
        while(iterato.hasNext())
        {
            System.out.println(iterato.next());
        }
        
    }
}