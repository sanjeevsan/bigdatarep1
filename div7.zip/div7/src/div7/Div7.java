/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package div7;

import java.util.Scanner;

/**
 *
 * @author San
 */
public class Div7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        div77 obj7=new div77();
        
    }
    
}
class div3
{
    Scanner sin=new Scanner(System.in);
    
   public void display()
    {
        int num,sum=0;
        
        System.out.println("enter the limit for 3 table");
        num=sin.nextInt();
        for(int i=0;i<num;i++)
        {
            if(i%3==0)
            {
                System.out.println("the div by 3 is "+ i);
                sum=sum+i;
                System.out.println(sum);
                
            }
        }
        
        
    }
}
class div5 extends div3
{
 
     public void display()
    {
        super.display();
        int num,sum=0;
        System.out.println("enter the limit for 5 table");
        num=sin.nextInt();
        for(int i=0;i<num;i++)
        {
            if(i%5==0)
            {
                System.out.println("the div by 5 is " + i);
                sum=sum+i;
                System.out.println(sum);
            }
        }
        int sum1=sum+sum;
        System.out.println(sum1);
    }
}
class div77 extends div5
{
    
     public void display()
             
    {
        super.display();
        int num,sum=0,num4;
        System.out.println("enter the limit for 7 table ");
        num=sin.nextInt();
        for(int i=1;i<num;i++)
        {
            if(i%7==0)
            {
                System.out.println("the div by 7 is " + i);
                sum=sum+i;
                System.out.println(sum);
            }
        }
        
        
       
        
    }
}