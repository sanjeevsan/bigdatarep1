/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package totalbonus;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Totalbonus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sin=new Scanner(System.in);
        String name;
        int salary,bonuscount=0;
        for(int i=1;i<=3;i++)
        {
            System.out.println("enter the name ");
            name=sin.next();
                        
            System.out.println("enter the sal ");
            salary=sin.nextInt();
            if(salary ==10000)
            bonuscount+=(salary/100)*30;
            else 
                if(salary ==50000)
 bonuscount+=(salary*20)/100;
      else
                    if(salary==100000)
                        
          bonuscount+=(salary*10)/100;
            
        }
        System.out.println("the total bonus count " + bonuscount);
    }
    
}
