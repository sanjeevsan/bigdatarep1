/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package link;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author San
 */
public class Link {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sin=new Scanner(System.in);
         LinkedList<A> str=new LinkedList<A>();
            
        String a,c;
        int b;
        
        for(int i=1;i<=2;i++)
        {
            System.out.println("enter the name");
            a=sin.next();
            System.out.println("enter the age ");
            b=sin.nextInt();
            System.out.println("enter the city");
            c=sin.next();
            A obj1=new A(a,b,c);
           
            str.add(obj1);
        }   
       
           
            
        
        
        ListIterator ltr=str.listIterator();
        while(ltr.hasNext())
        {
            System.out.println(ltr.next());
        }
    }   
   
   
    
}
class A
{
    String sname,scity;
    int sage;
    A(String name,int age,String city)
    {
        sname=name;
        scity=city;
        sage=age;
       
        
    }
}