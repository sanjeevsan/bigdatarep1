/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movie;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Movie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sin =new Scanner(System.in);
        String movieid,moviename,actorname,directorname,language,yearofrelease;
        int rating,totalincome,i=1,moviecounter=0,ratingcounter=0;
                int incomecounter=0,tamilcounter=0,englishcounter=0,directorcounter=0,totalcounter=0,durationcounter,duration,durationcounter1=0;
        do
        {
            System.out.println("enter the movie id");
            movieid=sin.next();
            if(movieid !=null)
            {
                moviecounter=moviecounter+1;
                
                
            }
            System.out.println("enter the movie name");
            moviename=sin.next();
            System.out.println("enter the actor name");
            actorname=sin.next();
            System.out.println("enter the director name");
            directorname=sin.nextLine();
            directorname+=sin.nextLine();
            
            if(directorname==" john D")
            {
                directorcounter=directorcounter+1;
            }
            System.out.println("enter the movie language in english or tamil");
            language=sin.next();
            if(language=="tamil")
            {
                tamilcounter=tamilcounter+1;
            }
            else
                if(language=="english")
                {
                    englishcounter=englishcounter+1;
                }
            System.out.println("enter the movie year of release");
            yearofrelease=sin.next();
            System.out.println("enter the movie rating");
            rating=sin.nextInt();
            if(rating >=4)
            {
                ratingcounter=ratingcounter+1;
                
            }
            System.out.println("enter the movie total income");
            totalincome=sin.nextInt();
            totalcounter=totalcounter+totalincome;
            System.out.println("enter the duration time");
            duration=sin.nextInt();
            durationcounter=duration*60;
            if(durationcounter1>90)
            {
                durationcounter1=durationcounter1+1;
            }
            i++;
            
        }while(i<3);
          System.out.println("the total number of movie is "+  moviecounter  );
           System.out.println("the total number of movie with same director  is "+  directorcounter  );
            System.out.println("the total number of movie is above 1.5hr is"+  durationcounter1  );
             System.out.println("the total number of movie rating is above or equal to4 star "+  ratingcounter  );
             System.out.println("the total income of movie is "+ totalcounter);
                          System.out.println("the total number of movie realsed in tamil is  "+ tamilcounter);

                                       System.out.println("the total number  of movie realsed in english  is "+ englishcounter);

             
}
    }
    
  
