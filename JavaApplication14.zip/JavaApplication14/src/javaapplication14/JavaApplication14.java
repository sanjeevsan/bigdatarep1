/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14;

import java.util.Scanner;

/**
 *
 * @author San
 */
public class JavaApplication14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sin=new Scanner(System.in);
        int a;
        int b;
         int i=0 ;
        System.out.println("enter the number ");
        a=sin.nextInt();
        while(a!=1){
            
                
        b=a/2;
        
            
        System.out.println("the quotient is " + b);
        if(a%2==0)
        {
            i=i;
            
        }
        else
            i=i+1;
        System.out.println("the binary value  is " + i);
        a=b;
        i=0;
        
        
    }
    }
        
    
}
