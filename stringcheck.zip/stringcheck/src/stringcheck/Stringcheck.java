/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringcheck;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Stringcheck {

    /**
     * @param args the command line arguments
     */
    Scanner sin=new Scanner(System.in);
    String s1;
    public static void main(String[] args) {
        // TODO code application logic here
         Stringcheck obj=new  Stringcheck();
         obj.display();
    }


    public void display()
    {
            System.out.println("enter the string ");
    s1=sin.next();
    char[] c=new char[25];
    c=s1.toCharArray();
    if(c[2]=='S'||c[2]=='s')
    {
        System.out.println("s is available ");
    }
    else
        System.out.println("s is not avilable");
    
}


}


