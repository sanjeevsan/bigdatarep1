/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package replace3char;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Replace3char {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String str;
        
        Scanner sin=new Scanner(System.in);
      System.out.println("enter the string ");
      str=sin.next();
      char[] c =new char[20];
      c=str.toCharArray();
      System.out.println(c);
      c[2]='t';
      System.out.println(c);
      
      
    }
    
}
