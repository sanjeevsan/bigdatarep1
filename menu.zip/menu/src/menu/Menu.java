/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

import java.util.Scanner;

/**
 *
 * @author San
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    int num;
    Scanner sin=new Scanner(System.in);
    int a=10,b=20,c;
    public static void main(String[] args) {
        // TODO code application logic here
        
        Menu obj=new Menu();
        obj.display();
    }
    public void display()
    {
        System.out.println("1.addition \n 2.subraction \n 3.multiplication \n 4.division \n 5. percentage \n 6.exit");
        for(int i=0;i<=100;i++)
        {
            System.out.println("enter the number");
            num=sin.nextInt();
            if(num==1)
            {
                addition();
            }
            else
                if(num==2)
                {
                    subraction();
                }
            else
                    if(num==3)
                    {
                        multiplication();
                    }
                        else
                        if(num==4)
                        {
                            division();
                        }
            else
                            if(num==5)
                            {
                                percentage();
                            }
            else
                                if(num==6)
                                {
                                    break;
                                }
        }
   
    }
   void  addition()
                {
                    c=a+b;
                    System.out.println(c);
                    
                }
     void  subraction()
                {
                    c=a-b;
                    System.out.println(c);
                    
                }
     void  multiplication()
                {
                    c=a*b;
                    System.out.println(c);
                    
                }
     void  division()
                {
                    c=a/b;
                    System.out.println(c);
                    
                }
       void  percentage()
                {
                    c=a%b;
                    System.out.println(c);
                    
                }
    
}
 

