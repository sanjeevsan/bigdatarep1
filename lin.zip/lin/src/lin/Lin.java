/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lin;

import java.util.ArrayList;
import java.util.ListIterator;

/**
 *
 * @author San
 */
public class Lin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList al=new ArrayList();
        al.add("jim");
        al.add("rim");
        al.add("tim");
        System.out.println("forward direction");
        ListIterator ltr=al.listIterator();
        while(ltr.hasNext())
        {
            System.out.println(ltr.next());
        }
        
           System.out.println("forward direction");
              
        
          while(ltr.hasPrevious())
        {
            System.out.println(ltr.previous());
        }
    }
    
}
