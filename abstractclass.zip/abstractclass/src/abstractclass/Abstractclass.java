/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractclass;

/**
 *
 * @author San
 */
public class Abstractclass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      acer obj=new acer();
      obj.display();
      obj.keypad();
      obj.siri();
      obj.touch();
    }
    
}
abstract class laptop
{
    public void display()
    {
        System.out.println("Hd");
        
    }
    public void keypad()
    {
        System.out.println("sensitive");
    }
    public abstract void touch();
    public abstract void siri();
}
abstract class hp extends laptop
{
   public void touch()
   {
       System.out.println("touc is invented");
   }
  
}
class acer extends  laptop
{
    public void siri()
    {
        System.out.println("acer invented siri");
    }
    public void touch()
   {
       System.out.println("touc is invented");
   }
}