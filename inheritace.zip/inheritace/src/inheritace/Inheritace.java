/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritace;

import java.util.Scanner;

/**
 *
 * @author San
 */
 
public class Inheritace {

    /**
     * @param args the command line arguments
     */
  
    
    
   
    public static void main(String[] args) {
        // TODO code application logic here
        maths obj=new maths();
        botony obj1=new botony();
        zoology obj2=new zoology();
        software obj3=new software();
        hardware obj4=new hardware();
        electronics obj5=new electronics();
        
        
    }
    
}
class details
{
      Scanner sin=new Scanner(System.in);
    String name;
  //  int age;
   // int id;
    String stream;
    details()
    {
    System.out.println("enter the name");
    name=sin.next();
     System.out.println("enter the stream");
    stream=sin.next();
    }
    
}
class maths extends details
{
    
    maths()
    {
        System.out.println("it is maths stream");
        
    }
}
class biology extends details
{
    
   biology()
   { 
        System.out.println("it is biology");
    }
}
    class botony extends biology
    {
        botony()
    {
        System.out.println("it is botany");
    }
    }
    class zoology extends biology
    {
        zoology()
    {
        System.out.println("it is zoology");
    }
    }

class computer extends details
{
  
  computer()
  {
      System.out.println("it is computer");
  }
}
class hardware extends computer
{
    hardware()
    {
       
    
        System.out.println("it is hardware");
    }
    
}
class software extends computer
{
    software()
    {
       
    
        System.out.println("it is software");
    }
    
}


class electronics extends details
{
    electronics()
    {
        System.out.println("it is electronics");
    }
          
}