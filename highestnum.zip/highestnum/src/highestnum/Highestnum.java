/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package highestnum;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class Highestnum {

    /**
     * @param args the command line arguments
     */
    int num1,num2,num3;
    Scanner sin=new Scanner(System.in);
    public static void main(String[] args) {
        // TODO code application logic here
        Highestnum obj=new Highestnum();
        obj.display();
        
    }
    public void display()
    {
        System.out.println("enter the number");
                num1=sin.nextInt();
                System.out.println("enter the number");
                num2=sin.nextInt();
                System.out.println("enter the number");
                num3=sin.nextInt();
                if(num1>num2 && num1>num3)
                {
                    System.out.println("the max num is " + num1);
                }
                else
                    
                 if(num2>num1 && num2>num3)
                {
                    System.out.println("the max num is " + num2);
                }
                else
                     
                 System.out.println("the max num is " + num3);
    }
    
}
