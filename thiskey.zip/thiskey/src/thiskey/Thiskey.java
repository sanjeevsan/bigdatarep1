/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thiskey;

/**
 *
 * @author San
 */
public class Thiskey {
        int a=0,b=0;
        

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Thiskey obj=new Thiskey();
        
        obj.display(2,5);
        
    }

    public void display(int a,int b)
    {
      this.a=a;
       this.b=b;
        System.out.println(a);
        System.out.println(b);
}
}