/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author MRuser
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sin=new Scanner(System.in);
        int num,numcounter=0;
        for(int i=1;i<=10;i++)
        {
            System.out.println("enter the number ");
            num=sin.nextInt();
            if(num>10)
            {
                numcounter=numcounter+1;
            }
        }
        System.out.println(numcounter);
    }
    
}
